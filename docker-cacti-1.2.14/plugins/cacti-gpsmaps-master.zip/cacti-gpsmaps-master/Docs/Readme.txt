GPSMaps for Cacti
Version 1.8

Author: Wixiweb, based on the work of Andy Aloia (andyaloia at gmail dot com, http://spiffdev.com/)
Email: contact@wixiweb.fr

About:
This plugin provides an integration of Google maps with cacti in order to visually map out hosts.
This plugin also aims to provide a coverage map for wireless based systems.

New Installation: (upgrade is below)
A)Requires Cacti and PIA working
B)Perform a database backup. (I'm warning you!)
C)Extract to the plugins directory just like any other plugin.
D)Make sure that the XML folder has write access.

The bare minimum amount of settings that must be set are:
Initial Latitude 
Initial Longitude
Initial Zoom
